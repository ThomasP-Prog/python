from operation import *
from utils import *


def main() -> None:
    """main function of the calculator"""
    num1 = None
    continue_calc = True
    while continue_calc == True:
        if not num1:
            num1 = get_number()
        result = calculus(num1)
        continue_calc = continue_calculating()
        if result != None:
            num1 = keep_result(num1,result)
        else:
            num1 = None

if __name__ == "__main__":
    main()
    